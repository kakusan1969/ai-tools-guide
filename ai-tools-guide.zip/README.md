
# AI 工具變現指南 × 可視化 HTML 頁面

本專案為一個簡單的 HTML 靜態頁面，展示了 AI 工具的應用與變現方式建議，使用 Tailwind CSS 美化介面。

## 如何部署到 GitHub Pages

1. 將此壓縮包內容全部上傳至您的 GitHub Repository（建議命名：ai-tools-guide）
2. 到 Repo 的 Settings → Pages → Source 選擇 `main` 分支
3. 儲存後，您將取得如下網址：

```
https://[你的GitHub帳號].github.io/ai-tools-guide/
```

## 作者

由郭老師 × 軍師 協作完成。
